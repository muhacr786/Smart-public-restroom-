from django.contrib import admin
from .models import Tissuesensor, Soapsensor, Smellsensor
# Register your models here.


admin.site.register(Tissuesensor)
admin.site.register(Soapsensor)
admin.site.register(Smellsensor)
